angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('bookSmartKktp', {
    url: '/page1',
    templateUrl: 'templates/bookSmartKktp.html',
    controller: 'bookSmartKktpCtrl'
  })

  .state('bookSmartKktp1', {
    url: '/page14',
    templateUrl: 'templates/bookSmartKktp1.html',
    controller: 'bookSmartKktp1Ctrl'
  })

  .state('bookSmartKktpSlider', {
    url: '/page20',
    templateUrl: 'templates/bookSmartKktpSlider.html',
    controller: 'bookSmartKktpSliderCtrl'
  })

  .state('mainMenu', {
    url: '/page2',
    templateUrl: 'templates/mainMenu.html',
    controller: 'mainMenuCtrl'
  })

  .state('visiMisi', {
    url: '/page23',
    templateUrl: 'templates/visiMisi.html',
    controller: 'visiMisiCtrl'
  })

  .state('matlamat', {
    url: '/page24',
    templateUrl: 'templates/matlamat.html',
    controller: 'matlamatCtrl'
  })

  .state('maklumatProgram', {
    url: '/page22',
    templateUrl: 'templates/maklumatProgram.html',
    controller: 'maklumatProgramCtrl'
  })

  .state('laguKolejKomuniti', {
    url: '/page18',
    templateUrl: 'templates/laguKolejKomuniti.html',
    controller: 'laguKolejKomunitiCtrl'
  })

  .state('videoKorporat', {
    url: '/page21',
    templateUrl: 'templates/videoKorporat.html',
    controller: 'videoKorporatCtrl'
  })

  .state('pencapaianKejayaanKolej', {
    url: '/page15',
    templateUrl: 'templates/pencapaianKejayaanKolej.html',
    controller: 'pencapaianKejayaanKolejCtrl'
  })

  .state('KeistimewaanKolejKomuniti', {
    url: '/page19',
    templateUrl: 'templates/KeistimewaanKolejKomuniti.html',
    controller: 'KeistimewaanKolejKomunitiCtrl'
  })

  .state('maklumatKorporat', {
    url: '/page11',
    templateUrl: 'templates/maklumatKorporat.html',
    controller: 'maklumatKorporatCtrl'
  })

  .state('maklumatPdP', {
    url: '/page7',
    templateUrl: 'templates/maklumatPdP.html',
    controller: 'maklumatPdPCtrl'
  })

  .state('jadualWaktu', {
    url: '/page9',
    templateUrl: 'templates/jadualWaktu.html',
    controller: 'jadualWaktuCtrl'
  })

  .state('semester1A', {
    url: '/page10',
    templateUrl: 'templates/semester1A.html',
    controller: 'semester1ACtrl'
  })

  .state('takwim', {
    url: '/page17',
    templateUrl: 'templates/takwim.html',
    controller: 'takwimCtrl'
  })

  .state('semester1B', {
    url: '/page13',
    templateUrl: 'templates/semester1B.html',
    controller: 'semester1BCtrl'
  })

  .state('semester3A', {
    url: '/page12',
    templateUrl: 'templates/semester3A.html',
    controller: 'semester3ACtrl'
  })

  .state('semester3B', {
    url: '/page16',
    templateUrl: 'templates/semester3B.html',
    controller: 'semester3BCtrl'
  })

  .state('maklumatPensyarah', {
    url: '/page8',
    templateUrl: 'templates/maklumatPensyarah.html',
    controller: 'maklumatPensyarahCtrl'
  })

  .state('penghargaan', {
    url: '/page6',
    templateUrl: 'templates/penghargaan.html',
    controller: 'penghargaanCtrl'
  })

  .state('hubungiKami', {
    url: '/page5',
    templateUrl: 'templates/hubungiKami.html',
    controller: 'hubungiKamiCtrl'
  })

$urlRouterProvider.otherwise('/page1')


});